
import UIKit

class LaunchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func LoginTapped(_ sender: Any) {
    }
    @IBAction func RegisterTapped(_ sender: Any) {
    }
    
    
    
}
